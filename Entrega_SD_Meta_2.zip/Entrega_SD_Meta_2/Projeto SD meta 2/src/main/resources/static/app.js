let stompClient = null;

const send = 0;
const send_aux = 0;
const tamanho = 0;
let count = 0;

function setConnected(connected) {
  $("#connect").prop("disabled", connected);
  $("#disconnect").prop("disabled", !connected);
  if (connected) {
    $("#conversation").show();
  } else {
    $("#conversation").hide();
  }
  $("#messages").html("");
}

function connect() {
  const socket = new SockJS('/my-websocket');
  stompClient = Stomp.over(socket);
  stompClient.connect({}, (frame) => {
    setConnected(true);
    console.log('Connected:', frame);

    stompClient.subscribe('/topic/messages', (message) => {


      showMessage(JSON.parse(message.body).content);
    });
  });
}

function disconnect() {
  if (stompClient !== null) {
    stompClient.disconnect();
  }
  setConnected(false);
  console.log("Disconnected");
}

function sendMessage() {
  stompClient.send("/app/message", {}, JSON.stringify({'content': $("#message").val()}));
}


let currentPage = 1;
const resultsPerPage = 10;

function showMessage(message) {

    // Clear the content of $("#messages")
    $("#messages").html('');

    if (message.split(' ')[0].split('[')[1] === "Downloader"){
        message.substring(1, message.length - 1).split(", ").forEach(item => {
            console.log("=====>"+item);
          const tableRow = "<tr><td><a " + item + ">" + item + "</a></td></tr>";
          $("#messages").append(tableRow);

        });

          return;
    }


    count = 0;


  const value = message.slice(1, -1);


  const arr = value.split(/(?=http)/);


  // Calculate the start and end index for the current page
  const startIndex = (currentPage - 1) * resultsPerPage;
  const endIndex = currentPage * resultsPerPage;

  const currentPageResults = arr.slice(startIndex, endIndex);

  count = arr.length;

  const new_aux = [];

  currentPageResults.forEach(item => {
    const aux = item.split("\n");

    if (aux != null && aux.length == 3 && aux[0].includes("http")) {
      const url = aux[0];
      const title = aux[1];
      const citation = aux[2];

      const tableRow = "<tr><td><a target='_blank' href='" + url + "'>" + title + "</a> <br>" + url + "<br>" + citation + "<td>";

      $("#messages").append(tableRow);
    }
  });

    /*lista com o resto
    new_aux.push(aux);


      currentPageResults.forEach(item => {
        const aux = item.split(" ");

        console.log(aux);
        if (aux[0] == "" && aux[3].includes("https")) {
          const url = aux[3];
          const tableRow = "<tr><td><a target='_blank' href='" + url + "'>" + url + "</a></td></tr>";
          $("#messages").append(tableRow);
        }

        if (aux[2].includes("https")) {
          const url = aux[2];
          const tableRow = "<tr><td><a target='_blank' href='" + url + "'>" + url + "</a></td></tr>";
          $("#messages").append(tableRow);
        }
      });*/


    //console.log("NEW_AUX: "+new_aux);

    //console.log("TAMANHO NEW_AUX: "+new_aux.length);
  // Display pagination buttons
  displayPagination(message);
}

function displayPagination(arr) {
    console.log("RESULTADOS: " + count);
  const totalPages = Math.ceil(count / resultsPerPage);

    $("#results").html('');
  $("#results").append("<th>Results (" + count + ")</th>");

  // Clear the pagination section
  $("#pagination").html('');

    console.log("PAGE ("+currentPage+"/"+totalPages+")");

  // Create previous button if not on the first page
  if (currentPage > 1) {
    const previousButton = "<button id='previousButton'>←</button>";
    $("#pagination").append(previousButton);
  }

  // Create next button if not on the last page
  if (currentPage < totalPages) {
    const nextButton = "<button id='nextButton'>→</button>";
    $("#pagination").append(nextButton);
  }

  const pageIndicator = "<div id='pageIndicator'>Page " + currentPage + " of " + totalPages + "</div>";
    $("#pagination").append(pageIndicator);

  // Bind click event handlers to the pagination buttons
  $("#previousButton").click(() => {
    currentPage--;
    showMessage(arr);
  });

  $("#nextButton").click(() => {
    currentPage++;
    showMessage(arr);
  });
}



function sendSelection() {
  const selectedOption = $("#options").val();
  const message = $("#message").val();
  console.log(selectedOption);
  stompClient.send("/app/logged", {}, JSON.stringify({
    'option': selectedOption, "value" : message
  }));
}

$(function () {
  $("form").on('submit', (e) => {
    e.preventDefault();
  });
  // Exercise 3.
  $("#connect").click(() => {
    connect();
  });
  $("#disconnect").click(() => {
    disconnect();
  });
  $("#send").click(() => {
    console.log(message);
    sendMessage();
    console.log("CLIQUEI SEND");
  });
   $("#login").click(() => {
      window.location.href = "/login";
    });
    $("#option_but").click(() => {
        sendSelection();
    });

});

$(document).ready(function(){
    connect();
});

$(document).unload(function(){
    disconnect();
});

// Exercise 3.
/*
window.onload = connect;
window.onbeforeunload = disconnect;
*/
