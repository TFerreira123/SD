package pt.uc.sd;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class HashMaps implements Serializable {
    public HashMap<String, List<String>> wordsURL;
    public HashMap<Link, List<String>> linksURL;
    public long downloaderId;
    public long t;

    public HashMaps(HashMap<String, List<String>> wordsURL, HashMap<Link, List<String>> linksURL, long downloaderId, long t) {
        this.wordsURL = wordsURL;
        this.linksURL = linksURL;
        this.downloaderId = downloaderId;
        this.t = t;
    }

    public void clear(){
        this.wordsURL.clear();
        this.linksURL.clear();
    }
}

