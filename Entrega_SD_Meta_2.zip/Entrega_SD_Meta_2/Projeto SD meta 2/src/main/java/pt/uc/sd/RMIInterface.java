package pt.uc.sd;

import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RMIInterface extends Remote {
    String sendMessage(String message) throws RemoteException;

    String sendMessage(String message, String username, String password) throws RemoteException;

    boolean createUser(String username, String password) throws RemoteException;

    boolean checkUser(String username, String password) throws RemoteException;

    String sendURL(String url) throws RemoteException;

    List<String> HandleRequest(int x, String s) throws RemoteException, NotBoundException;

    //void execute_order() throws RemoteException;
}