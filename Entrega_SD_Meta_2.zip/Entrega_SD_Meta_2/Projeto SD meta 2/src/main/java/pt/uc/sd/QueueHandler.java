package pt.uc.sd;

import java.io.*;
import java.net.*;
import java.util.*;

public class QueueHandler {

    private static final int SERVER_PORT = 6001;

    public static void main(String[] args) {

        Queue<String> urlQueue = new LinkedList<>();
        ArrayList<String> processedlinks = new ArrayList<>();



        urlQueue.add("https://www.w3schools.com");


        try {
            // Criar um server socket
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            Downloader down1 = new Downloader(processedlinks, urlQueue);
            Downloader down2 = new Downloader(processedlinks, urlQueue);
            down1.start();
            down2.start();

            // Keep listening for incoming connections
            while (true) {
                // aguardar pelo cliente ser conectar
                Socket clientSocket = serverSocket.accept();
                System.out.println("Received incoming connection from " + clientSocket.getInetAddress());

                // Create a buffered reader to read the message sent by the client
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // Ler a mensagem enviada por o cliente (RMIServer)
                String message = reader.readLine();
                System.out.println("URL link: " + message);

                // Processa o URL (adiciona-o à queue)
                if (message.contains("http")){
                    urlQueue.add(message);
                }

                // Fechar a socket do cliente
                clientSocket.close();

            }


        } catch (Exception e) {
            System.err.println("QueueHandler Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
