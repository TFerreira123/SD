package pt.uc.sd;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.HashMap;
import java.util.*;

public class Downloader extends Thread {
    public final Queue<String> urlQueue;
    public final ArrayList<String> processedlinks;

    public Downloader(ArrayList<String> processedlinks, Queue<String> urlQueue) {
        this.urlQueue = urlQueue;
        this.processedlinks = processedlinks;
    }

    //String url = args[0];
    public void run() {
        HashMap<String, List<String>> wordsURL = new HashMap<String, List<String>>();
        HashMap<Link, List<String>> linksURL = new HashMap<Link, List<String>>();

        List<String> values = new ArrayList<>();
        List<String> linksReferenced = new ArrayList<>();

        HashMaps hashmaps = new HashMaps(wordsURL, linksURL, this.getId(), 0);

        String MULTICAST_ADDRESS = "224.3.2.1";
        int PORT = 1234;
        long SLEEP_TIME = 5000;

        while (true) {


            try {
                this.sleep(1000); // pause for 1 second
            } catch (InterruptedException e) {
                // handle the exception here
                e.printStackTrace();
            }

            wordsURL.clear();
            linksURL.clear();
            values.clear();
            linksReferenced.clear();
            String url;
            Link urlInfo;
            hashmaps.clear();


            synchronized (urlQueue) {

                System.out.println("before: "+urlQueue);

                if (urlQueue.isEmpty()) {
                    continue;
                }
                url = urlQueue.remove();

                System.out.println("after: "+urlQueue);
            }

            //verifica se o url que foi retirado da fila ainda não foi processado
            synchronized (processedlinks){
                //se já foi, coloca na lista de url's analizados e continua para o próximo
                if (processedlinks.contains(url)){
                    continue;
                }
                else{
                    processedlinks.add(url);
                }
            }

            try {
                Document doc = Jsoup.connect(url).get();
                StringTokenizer tokens = new StringTokenizer(doc.text().replaceAll("\\<.*?>", ""));
                String token;
                String title = doc.title();

                //System.out.println("title: "+title);
                //System.out.println("text: "+doc.text());
                //extrair citação
                String citation = "";


                int countTokens = 0;
                while (tokens.hasMoreElements() && countTokens++ < 100) {
                    // printa as palavras encontradas no site
                    token = tokens.nextToken().toLowerCase();
                    values.add(token);

                    if (countTokens < 50){
                        citation = citation.concat(token+" ");
                    }
                }
                //System.out.println(tokens.nextToken().toLowerCase());

                urlInfo = new Link(url, title, citation, 0);

                //armazenar todas as palavras(values) no hashmap Words
                wordsURL.put(url, values);

                Elements links = doc.select("a[href]");
                for (Element link : links) {
                    // printa os links encontrados no site
                    linksReferenced.add(link.attr("abs:href"));
                    synchronized (urlQueue) {
                        urlQueue.add(link.attr("abs:href"));
                    }
                }
                linksURL.put(urlInfo, linksReferenced);
                //System.out.println(url + " -->" + linksURL.get(url));

                //Colocar tudo numa só estrutura para enviar por multicast
                hashmaps.wordsURL = wordsURL;
                hashmaps.linksURL = linksURL;
                hashmaps.downloaderId = this.getId();
                hashmaps.t = System.currentTimeMillis();

                //Enviar por multicast
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(bos);
                oos.writeObject(hashmaps);
                byte[] bytes = bos.toByteArray();

                InetAddress address = InetAddress.getByName(MULTICAST_ADDRESS);
                DatagramPacket packet = new DatagramPacket(bytes, bytes.length, address, PORT);

                MulticastSocket socket = new MulticastSocket();
                socket.send(packet);

                /*
                try {
                    this.sleep(5000); // pause for 1 second
                } catch (InterruptedException e) {
                    // handle the exception here
                    e.printStackTrace();
                }*/

            } catch (HttpStatusException e) {
                System.out.println("Page not found :(");
            } catch (IOException e){
                e.printStackTrace();
            } catch (IllegalArgumentException e){
                System.out.println("IllegalArgumentException.");
            }
        }
    }
}