package pt.uc.sd;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class RMIServer extends UnicastRemoteObject implements RMIInterface {

    private static final int SERVER_PORT = 6001;
    private static final String SERVER_HOSTNAME = "localhost";
    public RMIServer() throws RemoteException, NotBoundException {
        super();
    }

    public static void main(String[] args) {

        try {
            // Criar uma instância do objecto do servidor
            RMIServer server = new RMIServer();
            // Exportar o objecto do servidor e ligá-lo ao registo
            //RMIInterface stub = (RMIInterface) UnicastRemoteObject.exportObject(server,1);
            Registry registry = LocateRegistry.createRegistry(1097);
            registry.bind("RMIInterface", server);
            System.out.println("RMI Server is ready!");



        } catch (Exception e) {
            System.err.println("RMI Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public String sendMessage(String message) throws RemoteException {
        return null;
    }

    @Override
    public String sendMessage(String message, String username, String password) throws RemoteException {
        System.out.println("Received message from client: " + message);
        if (message.equals("register")) {
            createUser(username, password);
            return "User registered successfully!";
        } else if (message.equals("login")) {
            boolean success = checkUser(username, password);
            if (success) {
                return "User logged in successfully!";
            } else {
                return "Username or password incorrect!";
            }
        } else {
            return "ACK";
        }
    }

    public String sendURL(String url) throws RemoteException {

        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            if(!url.startsWith("www.")){
                url = "https://www." + url;
            }
             else {
                url = "https://" + url;
            }
        }
        try {
            // Abrir a tcp connection
            Socket socket = new Socket("localhost", 6001);

            // enviar o url
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(url.getBytes());
            outputStream.flush();

            // fechar a socket
            socket.close();
            System.out.println("URL sent successfully to the QueueHandler.");
        } catch (IOException e) {
            System.err.println("Error sending URL via TCP: " + e.getMessage());
            e.printStackTrace();
        }

        return url;
    }



    public boolean createUser(String username, String password) throws RemoteException {
        try {
            // Abre o ficheiro user txt para acrescentar novos utilizadores
            BufferedWriter writer = new BufferedWriter(new FileWriter("/users.txt", true));
            // Acrescenta a informaoao do novo utlizador
            writer.write(username + "," + password);
            writer.newLine();
            // Fecha o ficheiro
            writer.close();
            System.out.println("User " + username + " created successfully!");
        } catch (IOException e) {
            System.err.println("Error creating user: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean checkUser(String username, String password) throws RemoteException {
        // Carrega a informacao do utilizador por o ficheiro
        try {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\77dua\\OneDrive - Universidade de Coimbra\\Faculdade\\3 Ano\\2 semestre\\SD\\Projeto_SD_meta_2 (1)\\Projeto SD meta 2\\src\\main\\java\\pt\\uc\\sd\\users.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(username) && parts[1].equals(password)) {
                    System.out.println("Loggin of " +username+ " successfully!");
                    return true;
                }
            }
            br.close();
        } catch (IOException e) {
            System.err.println("Error reading user file: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<String> HandleRequest(int x, String s) throws RemoteException, NotBoundException {

        // Obter a registry do RMIStorage
        Registry registry2 = LocateRegistry.getRegistry("localhost", 1098);
        // Aguardar por objetos remotos
        RMIStorage stub2 = (RMIStorage) registry2.lookup("RMIStorage");

        switch (x){
            case 1:
                return stub2.searchWords(s);

            case 2:
                System.out.println(x);
                return stub2.searchURL(s);

            case 3:
                System.out.println(x);
                return stub2.getDownloaders();
            case 4:
                return stub2.mostCommonSearches();
            default:
                return null;
        }
    }
}
