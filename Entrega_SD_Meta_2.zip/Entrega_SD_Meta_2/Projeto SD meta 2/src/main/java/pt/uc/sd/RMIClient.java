package pt.uc.sd;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class RMIClient {
    public static void main(String[] args) {


        try {
            // Obter a registry
            Registry registry = LocateRegistry.getRegistry("localhost", 1097);

            // Aguardar por objetos remotos
            RMIInterface stub = (RMIInterface) registry.lookup("RMIInterface");

            Scanner scanner = new Scanner(System.in);
            Scanner input = new Scanner(System.in);
            String choice;
            int t =1;

            do {

                System.out.println("Please select an option:");
                System.out.println("1 Register");
                System.out.println("2 Loggin");
                System.out.println("3 Search something");
                System.out.println("4 Index an URL");
                System.out.println("5 System info");
                System.out.println("0 Exit");

                choice = input.nextLine();

                String s1 = "";

                switch (choice) {
                    case "1":

                        System.out.print("Enter a username: ");
                        String username = scanner.nextLine();
                        System.out.print("Enter a password: ");
                        String password = scanner.nextLine();
                        System.out.println(stub.sendMessage("register", username, password));
                        break;

                    case "2":

                        System.out.println("Enter username:");
                        String username2 = scanner.nextLine();
                        System.out.println("Enter password:");
                        String password2 = scanner.nextLine();

                        if (stub.checkUser(username2, password2)) {
                            do {
                                System.out.println("\nWelcome to the login menu!");
                                // login menu
                                System.out.println("\nPlease select an option:");
                                System.out.println("1 Search something");
                                System.out.println("2 Search an URL");
                                System.out.println("3 Index an URL");
                                System.out.println("4 System info");
                                System.out.println("5 Logout");

                                String choice2 = input.nextLine();
                                String s = "";

                                switch (choice2) {
                                    case "3":
                                        System.out.println("insert an URL to proccess");
                                        String url = scanner.nextLine();
                                        String url_link = (stub.sendURL(url));
                                        break;

                                    case "1":
                                        System.out.println("Search something");
                                        s = scanner.nextLine();
                                        s = s.toLowerCase();
                                        int c = 0;
                                        for(String s3: stub.HandleRequest(1, s)){
                                            System.out.println(s3);
                                            System.out.println();
                                            c++;
                                        }
                                        if (c == 0){
                                            System.out.println("Your search did not match any documents.\n\n");
                                        }
                                        break;

                                    case "2":
                                        System.out.println("Search an URL");
                                        s = scanner.nextLine();

                                        int c1 = 0;
                                        for (String s3: stub.HandleRequest(2, s)){
                                            System.out.println(s3);
                                            System.out.println();
                                            c1++;
                                        }

                                        if (c1 == 0){
                                            System.out.println("Your search did not match any documents.\n\n");
                                        }
                                        break;
                                    case "4":
                                        System.out.println("\n");
                                        for (String s3: stub.HandleRequest(3, "")){
                                            System.out.println(s3);
                                        }
                                        System.out.println();
                                        System.out.println("10 Most commmon searches on googol:");
                                        for (String s2 : stub.HandleRequest(4, "")){
                                            System.out.println(s2);
                                        }
                                        System.out.println();
                                        break;
                                    case "5":
                                        System.out.println("Goodbye!\n\n");
                                        t=0;
                                        break;
                                    default:
                                        System.out.println("Invalid choice, please try again.");

                                }
                            }while(t ==1 );


                        } else {
                            System.out.println("Invalid username or password.");
                        }
                        break;
                    case "3":
                        System.out.println("Search something");
                        s1 = scanner.nextLine();
                        s1 = s1.toLowerCase();
                        int c = 0;
                        for(String s: stub.HandleRequest(1, s1)){
                            System.out.println(s);
                            System.out.println();
                            c++;
                        }
                        if (c == 0){
                            System.out.println("Your search did not match any documents.\n\n");
                        }
                        break;
                    case "4":
                        System.out.println("insert an URL to proccess");
                        String url = scanner.nextLine();
                        String url_link = (stub.sendURL(url));
                        break;
                    case "5":
                        System.out.println("\n");
                        for (String s3: stub.HandleRequest(3, "")){
                            System.out.println(s3);
                        }
                        System.out.println();
                        System.out.println("10 Most commmon searches on googol:");
                        for (String s2 : stub.HandleRequest(4, "")){
                            System.out.println(s2);
                        }
                        System.out.println();
                        break;

                    case "0":
                        System.out.println("Thank You! Goodbye!");
                        System.exit(0);
                    default:

                        System.out.println("Invalid choice, please try again.");
                }
                stub.sendMessage(String.valueOf(choice));

            } while (true);

        } catch (Exception e) {
            System.err.println("RMI Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
