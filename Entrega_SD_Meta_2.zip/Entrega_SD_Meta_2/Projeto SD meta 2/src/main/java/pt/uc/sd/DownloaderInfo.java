package pt.uc.sd;

public class DownloaderInfo {
    public long downloaderId;
    public long t;

    public DownloaderInfo(long downloaderId, long t) {
        this.downloaderId = downloaderId;
        this.t = t;
    }
}
