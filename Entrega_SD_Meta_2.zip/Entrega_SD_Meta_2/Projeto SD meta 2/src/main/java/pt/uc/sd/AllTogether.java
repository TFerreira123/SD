package pt.uc.sd;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class AllTogether implements Serializable {
    public HashMap<String, List<Link>> wordsURL;
    public HashMap<String, List<Link>> linksURL;
    public List<SearchCount> searchCount;

    public AllTogether(HashMap<String, List<Link>> wordsURL, HashMap<String, List<Link>> linksURL, List<SearchCount> searchCount) {
        this.wordsURL = wordsURL;
        this.linksURL = linksURL;
        this.searchCount = searchCount;
    }
}
