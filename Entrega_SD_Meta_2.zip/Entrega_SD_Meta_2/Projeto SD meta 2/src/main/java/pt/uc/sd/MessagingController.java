package pt.uc.sd;

import org.springframework.ui.Model;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

@Controller
public class MessagingController {
    @MessageMapping("/message")
    @SendTo("/topic/messages")
    public Message onMessage(Message message) throws InterruptedException, RemoteException, NotBoundException {
        System.out.println("Message received " + message);
        Thread.sleep(1000);
        Registry registry2 = LocateRegistry.getRegistry("localhost", 1098);
        RMIStorage stub2 = (RMIStorage) registry2.lookup("RMIStorage");
        List<String> out = stub2.searchWords(message.content());
        return new Message(HtmlUtils.htmlEscape(String.valueOf(out)));
    }

    @PostMapping("/login")
    public String handleLogin(@RequestParam String username, @RequestParam String password, Model model) throws RemoteException, NotBoundException {
        Registry registry = LocateRegistry.getRegistry("localhost", 1097);
        RMIInterface stub = (RMIInterface) registry.lookup("RMIInterface");
        boolean login = stub.checkUser(username, password);
        System.out.println(login);
        if (login) {
            return "redirect:/loggedin";
        } else {
            model.addAttribute("error","LOGIN FAILED!");
            return  "login";
        }
    }

    @GetMapping("/loggedin")
    public String handleLoggedIn(){
        return "logged";
    }

    @GetMapping("/login")
    public String getLogin(){
        return "login";
    }


    @MessageMapping("/logged")
    @SendTo("/topic/messages")
    public Message handleDropdownSelection(@Payload String selectedOption, MessageHeaders headers) throws IOException, NotBoundException, ClassNotFoundException {
        // Assuming jsonString contains the JSON string you received
        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode jsonNode = objectMapper.readTree(selectedOption);

        System.out.println(selectedOption);

        String option = jsonNode.get("option").asText();
        String value = jsonNode.get("value").asText();

        System.out.println("Selected option: " + option);
        System.out.println("Selected value: " + value);

        if (option.equals("Search")) {
            Registry registry2 = LocateRegistry.getRegistry("localhost", 1098);
            RMIStorage stub2 = (RMIStorage) registry2.lookup("RMIStorage");
            List<String> out = stub2.searchWords(value);
            return new Message(HtmlUtils.htmlEscape(String.valueOf(out)));

        } else if (option.equals("URL")) {
            Registry registry2 = LocateRegistry.getRegistry("localhost", 1098);
            RMIStorage stub2 = (RMIStorage) registry2.lookup("RMIStorage");
            List<String> out = stub2.searchURL(value);
            return new Message(HtmlUtils.htmlEscape(String.valueOf(out)));
        } else if (option.equals("Index")) {
            Registry registry = LocateRegistry.getRegistry("localhost", 1097);
            RMIInterface stub = (RMIInterface) registry.lookup("RMIInterface");
            stub.sendURL(value);
            return new Message(HtmlUtils.htmlEscape("Success!"));
        } else if (option.equals("SearchHacker")) {
            getHacker(value);
            return new Message(HtmlUtils.htmlEscape("Success!"));
        } else if (option.equals("SearchHackerID")) {
            getHackerID(value);
            return new Message(HtmlUtils.htmlEscape("Success!"));
        }
        else if (option.equals("Info")) {
            //chamar as funcoes para apresentar as info do sistema
            Registry registry2 = LocateRegistry.getRegistry("localhost", 1098);
            RMIStorage stub2 = (RMIStorage) registry2.lookup("RMIStorage");
            List<String> out = stub2.getDownloaders();
            return new Message(HtmlUtils.htmlEscape(String.valueOf(out)));
        }



        return null;
    }


    public static void getHacker(String value) throws IOException, NotBoundException {

        Registry registry = LocateRegistry.getRegistry("localhost", 1097);
        RMIInterface stub = (RMIInterface) registry.lookup("RMIInterface");


        String apiToken = "<your_api_token>";
        String urlString = "https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty&auth=" + apiToken;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            if (conn.getResponseCode() == 200) {
                String responseString = new Scanner(conn.getInputStream(), "UTF-8").useDelimiter("\\Z").next();

                String[] responseArray = responseString.split(",");
                int[] intArray = new int[responseArray.length];

                for (int i = 0; i < responseArray.length; i++) {
                    String numericString = responseArray[i].replaceAll("[^\\d]", "");
                    intArray[i] = Integer.parseInt(numericString);
                }

                for (int i = 0; i < intArray.length; i++) {

                    String news_id = "https://hacker-news.firebaseio.com/v0/item/" + intArray[i] + ".json";

                    try {
                        URL url2 = new URL(news_id);
                        HttpURLConnection conn2 = (HttpURLConnection) url2.openConnection();
                        conn2.setRequestMethod("GET");

                        if (conn2.getResponseCode() == 200) {
                            String userString = new Scanner(conn2.getInputStream(), "UTF-8").useDelimiter("\\Z").next();
                            ObjectMapper objectMapper = new ObjectMapper();
                            JsonNode jsonNode = objectMapper.readTree(userString);
                            JsonNode text = jsonNode.get("text");
                            JsonNode urlNode = jsonNode.get("url");
                            if (urlNode != null && !urlNode.isNull()) {
                                String url_aux = urlNode.asText();
                                if(text != null && !text.isNull()){
                                    String text_aux = text.asText();

                                    if (text_aux.contains(value)) {
                                        System.out.println(url_aux);
                                        stub.sendURL(url_aux);
                                    } else {
                                        continue;
                                    }
                                }


                            }

                        } else {
                            System.out.println("Failed to retrieve top stories: " + conn2.getResponseCode());
                        }
                        conn2.disconnect();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

            } else {
                System.out.println("Failed to retrieve top stories: " + conn.getResponseCode());
            }

            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public static void getHackerID(String value) throws IOException, NotBoundException {

        Registry registry = LocateRegistry.getRegistry("localhost", 1097);
        RMIInterface stub = (RMIInterface) registry.lookup("RMIInterface");


        String urlString = "https://hacker-news.firebaseio.com/v0/user/" + value + ".json";

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            if (conn.getResponseCode() == 200) {
                String userString = new Scanner(conn.getInputStream(), "UTF-8").useDelimiter("\\Z").next();
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(userString);

                JsonNode sub = jsonNode.get("submitted");
                int[] arr = new int[sub.size()];
                for (int i = 0; i < sub.size(); i++) {
                    arr[i] = sub.get(i).asInt();
                }

                for (int j : arr) {

                    String aux_con = "https://hacker-news.firebaseio.com/v0/item/" + j + ".json";
                    try {
                        URL url2 = new URL(aux_con);
                        HttpURLConnection conn2 = (HttpURLConnection) url2.openConnection();
                        conn2.setRequestMethod("GET");

                        if (conn2.getResponseCode() == 200) {
                            String subString = new Scanner(conn2.getInputStream(), "UTF-8").useDelimiter("\\Z").next();
                            ObjectMapper objectMapper2 = new ObjectMapper();
                            JsonNode jsonNode2 = objectMapper2.readTree(subString);
                            JsonNode urlNode = jsonNode2.get("url");
                            JsonNode type = jsonNode2.get("type");


                            if ((urlNode != null && !urlNode.isNull()) && (type != null && !type.isNull())) {
                                String url_aux = urlNode.asText();
                                String type_aux = type.asText();

                                if(type_aux.compareTo("story")==0){

                                    stub.sendURL(url_aux);
                                }

                            }

                        } else {
                            System.out.println("Failed to retrieve top stories: " + conn2.getResponseCode());
                        }
                        conn2.disconnect();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}