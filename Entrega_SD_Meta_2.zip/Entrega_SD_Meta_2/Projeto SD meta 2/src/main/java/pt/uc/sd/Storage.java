package pt.uc.sd;

import java.io.*;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Comparator;

public class Storage extends UnicastRemoteObject implements RMIStorage {
    private static final String MULTICAST_ADDRESS = "224.3.2.1";
    private static final int PORT = 1234;

    private InetAddress group;
    private MulticastSocket socket;

    private HashMap<String, List<Link>> wordsURL;
    private HashMap<String, List<Link>> linksURL;
    private List<SearchCount> searchCount;
    private List<DownloaderInfo> downloaders;

    public Storage() throws RemoteException{
        super();
        this.wordsURL = new HashMap<String, List<Link>>();
        this.linksURL = new HashMap<String, List<Link>>();
        this.searchCount = new ArrayList<SearchCount>();
        this.downloaders = new ArrayList<DownloaderInfo>();
    }

    public void startListening() {
        try {
            Registry registry = LocateRegistry.createRegistry(1098);
            registry.bind("RMIStorage", this);
            System.out.println("Storage is Ready");


            group = InetAddress.getByName(MULTICAST_ADDRESS);
            if (!group.isMulticastAddress()) {
                throw new IllegalArgumentException("Not a multicast address.");
            }
            socket = new MulticastSocket(PORT);
            socket.joinGroup(group);

            System.out.println("Storage running. Waiting for packets");

            //ler a informacao ja armazenada no ficheiro txt
            readFile();

            int x = 0;

            while (true) {
                byte[] buf = new byte[socket.getReceiveBufferSize()];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                byte[] data = packet.getData();
                if (data.length == 0) {
                    continue;
                }
                ByteArrayInputStream in = new ByteArrayInputStream(data);
                ObjectInputStream ois = new ObjectInputStream(in);

                // read the incoming HashMap and store the values in the class fields
                HashMaps hashMap = (HashMaps) ois.readObject();

                HashMap<String, List<String>> words = hashMap.wordsURL;
                HashMap<Link, List<String>> links = hashMap.linksURL;

                //verificar se a lista de downloads não contem o id do download recebido
                if (!contains_donwloaderId(hashMap.downloaderId)) {
                    this.downloaders.add(new DownloaderInfo(hashMap.downloaderId, hashMap.t));
                }
                //atualiza o tempo do ultimo envio deste downloader
                else{
                    for (DownloaderInfo d : downloaders){
                        if (d.downloaderId == hashMap.downloaderId){
                            d.t = hashMap.t;
                            break;
                        }
                    }
                }


                //System.out.println(this.wordsURL);

                //Adicionar o HashMap DAS PALAVRAS recebido ao HashMap principal
                Map.Entry<String, List<String>> firstEntry = words.entrySet().iterator().next();
                List<String> wordsList = firstEntry.getValue();

                Map.Entry<Link, List<String>> linkFirstEntry = links.entrySet().iterator().next();
                List<String> linksList = linkFirstEntry.getValue();

                String url = firstEntry.getKey();

                //System.out.println(url);

                for (String w : wordsList) {
                    if (this.wordsURL.containsKey(w)) {
                        if (!contains_url(this.wordsURL.get(w), url)) {
                            this.wordsURL.get(w).add(linkFirstEntry.getKey());
                        }
                    } else {
                        List<Link> novalista = new ArrayList<>();
                        novalista.add(linkFirstEntry.getKey());
                        this.wordsURL.put(w, novalista);
                    }
                }


                //Adicionar o HashMap DOS LINKS recebido ao HashMap principal


                for (String l : linksList) {
                    if (this.linksURL.containsKey(l)) {
                        if (!contains_url(this.linksURL.get(l), url)) {
                            this.linksURL.get(l).add(linkFirstEntry.getKey());
                        }
                    } else {
                        List<Link> novalista = new ArrayList<>();
                        novalista.add(linkFirstEntry.getKey());
                        this.linksURL.put(l, novalista);
                    }
                }


                //atualiza o ficheiro com a informacao processada
                writeFile();


                //System.out.println(this.wordsURL);
                //System.out.println(this.linksURL);

                // print the received HashMaps
                /*
                System.out.println("Received HashMaps:");
                System.out.println("wordsURL: " + getWordsURL());
                System.out.println("linksURL: " + getLinksURL());
                */

            }

        } catch (IOException | ClassNotFoundException | NullPointerException | AlreadyBoundException e) {
            e.printStackTrace();
        } finally {

            if (socket != null) {
                try {
                    socket.leaveGroup(group);
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void readFile(){
        try (FileInputStream fileIn = new FileInputStream("C:\\Users\\77dua\\OneDrive - Universidade de Coimbra\\Faculdade\\3 Ano\\2 semestre\\SD\\Projeto_SD_meta_2 (1)\\Projeto SD meta 2\\src\\main\\java\\pt\\uc\\sd\\info.txt");
             ObjectInputStream in = new ObjectInputStream(fileIn)) {

            // Read the object from the file
            Object obj = in.readObject();

            AllTogether myObj = (AllTogether) obj;

            this.wordsURL = myObj.wordsURL;
            this.linksURL = myObj.linksURL;
            this.searchCount = myObj.searchCount;

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void writeFile(){
        AllTogether obj = new AllTogether(this.wordsURL, this.linksURL, this.searchCount);

        try (FileOutputStream fileOut = new FileOutputStream("C:\\Users\\77dua\\OneDrive - Universidade de Coimbra\\Faculdade\\3 Ano\\2 semestre\\SD\\Projeto_SD_meta_2 (1)\\Projeto SD meta 2\\src\\main\\java\\pt\\uc\\sd\\info.txt");
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {

            // Write the object to the file
            out.writeObject(obj);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public List<String> searchURL(String url) throws RemoteException{
        List<String> s = new ArrayList<String>();

        if (this.linksURL.containsKey(url)) {
            for (Link l : this.linksURL.get(url)) {
                s.add(String.format("%s\n%s\n%s", l.url, l.title, l.citation));
            }
        }
        return s;
    }

    @Override
    public List<String> searchWords(String search) throws RemoteException {

        List<String> s = new ArrayList<String>();

        //adicionar esta pesquisa à lista de pesquisas feitas

        insert_search(search);

        List<Link> matchingLinks = new ArrayList<Link>();
        int count;

        String[] wordsList = search.split(" ");

        try {
            if (this.wordsURL.containsKey(wordsList[0])) {
                for (Link link : this.wordsURL.get(wordsList[0])) {
                    count = 0;

                    for (String w : wordsList) {
                        if (this.wordsURL.containsKey(w) && contains_url(this.wordsURL.get(w), link.url)) {
                            count++;
                        }
                    }
                    if (count == wordsList.length) {
                        matchingLinks.add(new Link(link.url, link.title, link.citation, this.linksURL.get(link.url).size()));
                    }
                }

                //dar a prioridade certa a cada link, tendo em conta o numero de paginas que os referencia
                //ordenar o array de urls por ordem de importancia
                matchingLinks.sort(Comparator.comparing(Link::getPriority).reversed());

                //imprime lista de links

                for (Link l : matchingLinks) {
                    System.out.println(l.url);
                    System.out.println(l.title);
                    System.out.println(l.citation);
                    System.out.println();
                    s.add(String.format("%s\n%s\n%s", l.url, l.title, l.citation));
                }

                System.out.println("SearchWords completed");
                return s;
            }

        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
        }

        return s;
    }

    //Assume-se que um downloader está ativo se tiver enviado algo há menos de 60 segundos
    @Override
    public List<String> getDownloaders() throws RemoteException{
        List<String> s = new ArrayList<String>();
        System.out.println("Entrei getDownloaders()");
        for (DownloaderInfo d : this.downloaders){
            if (System.currentTimeMillis() - d.t <= 60000){
                s.add("Downloader "+d.downloaderId+" active.");
                System.out.println(d.downloaderId);
            }
        }
        return s;
    }


    public boolean contains_donwloaderId(long id){

        for (DownloaderInfo d : this.downloaders){
            if (d.downloaderId == id){
                return true;
            }
        }
        return false;
    }


    public boolean contains_url(List<Link> lista, String url){

        if (lista.size() > 0){
            for (Link l : lista){
                if (l.url.equals(url)){
                    return true;
                }
            }
        }
        return false;
    }

    public int n_downloaders(List<Long> l){
        return l.size();
    }

    public void insert_search(String url){
        int contains = 0;
        if (this.searchCount.size() > 0){
            for (SearchCount s : this.searchCount){
                if (s.search.equals(url)){
                    s.count++;
                    contains++;
                    break;
                }
            }
            if (contains == 0){
                this.searchCount.add(new SearchCount(url, 0));
            }
        }

        else{
            this.searchCount.add(new SearchCount(url, 0));
        }

        this.searchCount.sort(Comparator.comparing(SearchCount::getCount).reversed());
    }

    @Override
    public List<String> mostCommonSearches(){

        List<String> searches = new ArrayList<String>();
        int count = 0;

        for (SearchCount s : this.searchCount){
            if (count < 10) {
                searches.add(s.search);
                count++;
            }
            else{
                break;
            }
        }
        return searches;
    }


    // Getters and setters for wordsURL and linksURL
    public HashMap<String, List<Link>> getWordsURL() {
        return wordsURL;
    }

    public HashMap<String, List<Link>> getLinksURL() {
        return linksURL;
    }

    public void setWordsURL(HashMap<String, List<Link>> wordsURL) {
        this.wordsURL = wordsURL;
    }

    public void setLinksURL(HashMap<String, List<Link>> linksURL) {
        this.linksURL = linksURL;
    }

    public static void main(String[] args) throws RemoteException {
        Storage storage = new Storage();
        storage.startListening();
    }
}