package pt.uc.sd;
import java.net.MulticastSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.io.IOException;
import java.util.HashMap;

public class MulticastServer extends Thread {
    private String MULTICAST_ADDRESS = "224.3.2.1";
    private int PORT = 4321;
    private long SLEEP_TIME = 5000;

    public static void main(String[] args) {
        MulticastServer server = new MulticastServer();
        server.start();
    }

    public MulticastServer() {
        super("Server " + (long) (Math.random() * 1000));
    }

    public void run() {
        MulticastSocket socket = null;
        long counter = 0;
        System.out.println(this.getName() + " running...");
        try {
            socket = new MulticastSocket();  // create socket without binding it (only for sending)
            while (true) {
                HashMap<String, Object> message = new HashMap<>();
                message.put("text", this.getName() + " packet " + counter++);
                message.put("metadata", "some metadata");

                // Convert the HashMap to a byte array using a custom serialization method
                byte[] buffer = serialize(message);

                InetAddress group = InetAddress.getByName(MULTICAST_ADDRESS);
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length, group, PORT);
                socket.send(packet);

                try { sleep((long) (Math.random() * SLEEP_TIME)); } catch (InterruptedException e) { }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            socket.close();
        }
    }

    /**
     * Converts a HashMap to a byte array using a custom serialization method.
     */
    private byte[] serialize(HashMap<String, Object> data) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (String key : data.keySet()) {
            sb.append(key);
            sb.append(":");
            sb.append(data.get(key).toString());
            sb.append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString().getBytes();
    }
}

/*
public class MulticastServer {
    public static void main(String[] args) throws IOException {
        // create a multicast socket
        MulticastSocket multicastSocket = new MulticastSocket();

        // set the IP address and port to multicast to
        InetAddress multicastAddress = InetAddress.getByName("224.1.1.1");
        int port = 10000;

        Map<String, Object> message = new HashMap<>();

        message.put("metadata", new HashMap<String, Object>() ;

        // serialize the hashmap as JSON
        String messageJson = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(message);

        // create a datagram packet with the message data
        byte[] buffer = messageJson.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, multicastAddress, port);

        // send the datagram packet to the multicast address
        multicastSocket.send(packet);

        // close the socket
        multicastSocket.close();
    }
}
*/