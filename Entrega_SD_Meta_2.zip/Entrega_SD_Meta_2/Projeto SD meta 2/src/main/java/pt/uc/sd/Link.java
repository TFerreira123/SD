package pt.uc.sd;

import java.io.Serializable;

public class Link implements Serializable {
    public String url;
    public String title;
    public String citation;
    public int priority;

    public Link(String url, String title, String citation, int priority) {
        this.url = url;
        this.title = title;
        this.citation = citation;
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }
}
