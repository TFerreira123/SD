package pt.uc.sd;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RMIStorage extends Remote{
    List<String> searchWords(String search) throws RemoteException;
    List<String> getDownloaders() throws RemoteException;
    List<String> searchURL(String url) throws RemoteException;
    List<String> mostCommonSearches() throws RemoteException;
}
