package pt.uc.sd;

import java.io.Serializable;

public class SearchCount implements Serializable {
    public String search;
    public int count;

    public SearchCount(String search, int count) {
        this.search = search;
        this.count = count;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
