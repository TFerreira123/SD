Para executar a apliação deve seguir os seguintes passos:
	-ir ao ficheiro RMIServer, linha 116, e alterar o caminho do ficheiro info.txt para o caminho correto no computador em questão;
	-ir ao ficheiro Storage.java e executar a mesma alteração mas nas linhas 166 e 186
	-correr os programas ChatApp.java, RMIServer, QueueHandler e Storage, por esta ordem.